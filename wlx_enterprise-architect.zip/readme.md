# wlx_enterprise-architect

Total Commander Lister-Plugin (WLX) for viewing UML class diagrams stored in
Sparx Enterprise Architect's SQLite-based project files (`.qea` / `.qeax`),
in both the F3 quick view and the Ctrl+Q panel.

v1 scope: class diagrams only (boxes with attribute/operation compartments,
generalization/realization/association/aggregation/composition, notes,
packages, interfaces). Read-only — no editing, no other diagram types yet.

## Dependency: sqlite3.dll

This plugin does not bundle SQLite. You must place the official `sqlite3.dll`
next to `eaviewer.wlx` (32-bit) and/or `eaviewer.wlx64` (64-bit) — matching
Total Commander's own bitness — before the plugin can open any file.

Download the precompiled Windows binaries from the SQLite project itself:

- 64-bit: [sqlite-dll-win-x64-3530400.zip](https://www.sqlite.org/2026/sqlite-dll-win-x64-3530400.zip)
- 32-bit: [sqlite-dll-win-x86-3530400.zip](https://www.sqlite.org/2026/sqlite-dll-win-x86-3530400.zip)

(Both linked from the official [SQLite download page](https://www.sqlite.org/download.html) —
check there for a newer version if these links go stale.)

Unzip each archive and copy the contained `sqlite3.dll` next to the matching
plugin file.

## Build

See the repository-wide `CLAUDE.md` for the Lazarus/FPC build setup. Two
build modes in `eaviewer.lpi`:

```
lazbuild.exe --build-mode="Release 32" eaviewer.lpi
lazbuild.exe --build-mode="Release 64" eaviewer.lpi
```

Produces `eaviewer.wlx` (32-bit) and `eaviewer.wlx64` (64-bit).

## Known v1 limitations

- Connectors are drawn as straight lines between object edges, not via the
  routed waypoints stored in `t_diagramlinks.Geometry` — see the header
  comment in `uRenderClass.pas`.
- Interfaces are rendered as boxes with a `<<interface>>` stereotype, not as
  the "lollipop" circle notation EA sometimes uses.
- Stereotype icons are not rendered (deliberately out of scope for v1).
- Schema verified against community documentation, not yet against a real
  EA-generated `.qea` file — see `uEaModel.pas` header for sources. Re-check
  against a real file once available.
